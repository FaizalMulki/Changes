﻿app.controller("ReportController", function ($scope, $http) {
    $scope.model = {};
    $scope.model.txtSearch = "";
    $scope.model.FromDate = moment().subtract(30, "days").format("DD-MM-YYYY");
    $scope.model.ToDate = moment().add(1, 'days').format("DD-MM-YYYY");

    $scope.HideLoaderImg = function () {
        $('#LoadingImg').hide();
    }

    $scope.ShowLoaderImg = function () {
        $('#LoadingImg').show();
    }

    $scope.reportGridOptions = {
        dataSource: {
            type: "json",
            transport: {
                read: {
                    url: baseUrl + 'Report/GetAllItemsReport',
                    dataType: "json",
                },
                parameterMap: function (options, operation) {
                    debugger;
                    var opt = {};
                    opt = options;
                    opt.Search = $scope.model.txtSearch;
                    opt.FromDate = $scope.model.FromDate;
                    opt.ToDate = $scope.model.ToDate;
                    return opt;
                },
            },
            schema:
                    {
                        model:
                        {
                            id: "Id",
                            fields: {


                            }
                        }
                    },

            serverPaging: true,
            schema: {
                data: function (response) {
                    if (response) {
                        return JSON.parse(response.Result);
                    }
                    return [];
                },
                total: 'Total',

            }
        },
        sortable: {
            mode: "single",
            allowUnsort: true
        },
        pageable: { pageSize: GridPageSize, refresh: true },
        resizeable: true,
        scrollable: false,
        toolbar: [
         
        {
           template: "&nbsp;<a href='javascript:void(0);' class='btn btn-export'  ng-click='exportToExcel(\"report\")' data-toggle='tooltip' title='Export to Excel'><i class='fa fa-file-excel-o'></i></a>",
         }
        ],
        columns: [
          
            {
                   field: "Subject",
                   title: "Subject",
                   width: "80px",
                   filterable: false,


            },
              {
                  field: "Message",
                  title: "Message",
                  width: "80px",
                  filterable: false,


              },
              {
                  field: "Reply",
                  title: "Reply",
                  width: "80px",
                  filterable: false,


              },


            {
                field: "BranchName",
                title: "Branch",
                width: "80px",
                filterable: false,
            },
             {
                 field: "EmployeeName",
                 title: "Employee",
                 width: "80px",
                 filterable: false,
             },


             
               {
                   field: "StatusName",
                   title: "Status",
                   width: "120px",
                   filterable: false,
               },
                {
                    field: "DeletedStatus",
                    title: "Is Deleted",
                    width: "120px",
                    filterable: false,
                },
               
               
               {
                   field: "CreatedBy",
                   title: "Created By",
                   width: "60px",
                   filterable: false,
               },

        ]
    };

    $scope.checkData = function (e) {
        $("#ReportGrid").data("kendoGrid").dataSource.read();
    }

    $scope.exportToExcel = function () {
        debugger
       $scope.PostModel={};
       $scope.PostModel.FromDate = $scope.model.FromDate;
       $scope.PostModel.ToDate = $scope.model.ToDate;
        //var response = $http({
        //    method: 'Get',
        //    showloader: true,
        //    url: baseUrl + 'Report/GetAllItemsForExport',
        //    data: $scope.PostModel
           
        //})
        //response.then(function (data) {
        //    var result = data.data;
        //    if (result.length != 0) {              
        //        var TableResult = convertJSONtoTable(result);
        //        $(TableResult).hide().appendTo("body")
        //        $("#exporttable").table2excel({
        //            name: "Table2Excel",
        //            filename: "Message",
        //            fileext: ".xlsx"
        //        });
        //    }
        //    else {
        //        ShowMessage("No Records To Export", "A");
        //    }

        //    HideLoader();
        //});






        $http({
            method: 'POST',
            url: baseUrl + 'Report/GetAllItemsForExport',
            data: $scope.PostModel
        }).then(function (response) {
            debugger;

            var result = data.data;
            if (result.length != 0) {
                var TableResult = convertJSONtoTable(result);
                $(TableResult).hide().appendTo("body")
                $("#exporttable").table2excel({
                    name: "Table2Excel",
                    filename: "Message",
                    fileext: ".xlsx"
                });
            }
            else {
                ShowMessage("No Records To Export", "A");
            }

            HideLoader();

        }, function errorCallback(response) {
          HideLoaderImg();


        });



    };


    function convertJSONtoTable(response) {
        $("#exporttable").remove();
        var result = "<table id='exporttable'>";

        var keysHtml = [];
        var keysHtmlformat = [];
        var flag = 0;

        response.forEach(function (obj, idx) {
            var gridname = 'ReportGridExcel';
            if (flag == 0) {
                var columns = $("#ReportGrid").data("kendoGrid").columns
                result = result + "<thead><tr>";
                if (columns.length > 0) {
                    for (var i = 0; i < columns.length; i++) {
                        var col = columns[i];
                        if (col.attributes != undefined && col.attributes.style.search("display:none") >= 0)
                            continue;

                        if (col.field != undefined && col.hidden != true) {
                            result = result + "<th><b>" + col.title + "</b></th>"; // adding Grid header names
                            keysHtml.push(col.field);
                            keysHtmlformat.push(col.format);
                        }
                    }
                }
                result = result + "</tr></thead><tbody>";
            }
            result = result + "<tr>";
            keysHtml.forEach(function (key, idx) {
                var itemVal = obj[key];
                if (itemVal != null) {
                    var itemVal2 = itemVal.toString();                                                    
                }
                else {
                    itemVal = "";
                }
                //if (itemVal != null && (keysHtml[idx] == "InsuranceAmount" || keysHtml[idx] == "Debit" || keysHtml[idx] == "Credit" || keysHtml[idx] == "Amount" || keysHtml[idx] == "Earnings" || keysHtml[idx] == "Deductions" || keysHtml[idx] == "NetPay")) {
                //    result = result + "<td style='mso-number-format:\"#,##0.00\"'>" + itemVal + "</td>";    // adding indivisual cell values
                //}
                //else
                    result = result + "<td>" + itemVal + "</td>";    // adding indivisual cell values
            });
            result = result + "</tr>";
            flag = 1;
        });

        result = result + "</tbody></table>";
        return result;
    }

    $scope.messageGridExcelOptions = {
        columns: [
             {
                 field: "Subject",
                 title: "Subject",
                 width: "80px",
                 filterable: false,


             },
              {
                  field: "Message",
                  title: "Message",
                  width: "80px",
                  filterable: false,


              },
               {
                   field: "Reply",
                   title: "Reply",
                   width: "80px",
                   filterable: false,


               },


            {
                field: "BranchName",
                title: "Branch",
                width: "80px",
                filterable: false,
            },
             {
                 field: "EmployeeName",
                 title: "Employee",
                 width: "80px",
                 filterable: false,
             },



               {
                   field: "StatusName",
                   title: "Status",
                   width: "120px",
                   filterable: false,
               },
                {
                    field: "DeletedStatus",
                    title: "Is Deleted",
                    width: "120px",
                    filterable: false,
                },

               {
                   field: "CreatedBy",
                   title: "Created By",
                   width: "60px",
                   filterable: false,
               },
        ]
    };

    $scope.GroupSearch = function (e) {
        $("#ReportGrid").data("kendoGrid").dataSource.read();

    }
});